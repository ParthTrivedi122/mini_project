from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

def caesar_brute_force(ciphertext, meaningful_words):
    decrypted_text = ''
    found_meaningful_word = False
    # Loop through all possible shifts
    for shift in range(1, 26):
        decrypted_text = ''
        for char in ciphertext:
            if 'A' <= char <= 'Z':
                decrypted_char = chr(((ord(char) - 65 - shift + 26) % 26) + 65)
            elif 'a' <= char <= 'z':
                decrypted_char = chr(((ord(char) - 97 - shift + 26) % 26) + 97)
            else:
                decrypted_char = char
            decrypted_text += decrypted_char
        # Check if any word in the decrypted text is meaningful
        if any(word in decrypted_text.lower() for word in meaningful_words):
            found_meaningful_word = True
            break
    if found_meaningful_word:
        return decrypted_text
    else:
        return "No meaningful word found in decrypted text."

@app.route('/brute-force', methods=['POST'])  # Allow POST method
def handle_brute_force():
    data = request.get_json()
    ciphertext = data.get('ciphertext')
    meaningful_words = data.get('meaningful_words')
    result = caesar_brute_force(ciphertext, meaningful_words)
    return jsonify({'result': result})

if __name__ == '__main__':
    app.run(debug=True)
